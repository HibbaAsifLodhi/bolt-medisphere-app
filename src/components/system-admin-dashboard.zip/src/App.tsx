import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { PrintableEmergencyCard } from './components/PrintableEmergencyCard.tsx';
import { LandingPage } from './components/LandingPage.tsx';
import { HomeDashboard } from './views/HomeDashboard.tsx';
import { EmergencySosView } from './views/EmergencySosView.tsx';
import { EmergencyFileView } from './views/EmergencyFileView.tsx';
import { EmergencyAuditView } from './views/EmergencyAuditView.tsx';
import { SpinalImagingView } from './views/SpinalImagingView.tsx';
import { PhysioDashboardView } from './views/PhysioDashboardView.tsx';
import { AiAssistantView } from './views/AiAssistantView.tsx';
import { UrduHubView } from './views/UrduHubView.tsx';
import { SdgImpactView } from './views/SdgImpactView.tsx';
import { PatientProfileView } from './views/PatientProfileView.tsx';
import { MedicalHistoryView } from './views/MedicalHistoryView.tsx';
import { PrescriptionsView } from './views/PrescriptionsView.tsx';
import { LabReportsView } from './views/LabReportsView.tsx';
import { MriCtViewerView } from './views/MriCtViewerView.tsx';
import { AppointmentsView } from './views/AppointmentsView.tsx';
import { DirectoryView } from './views/DirectoryView.tsx';
import { ExerciseLibraryView } from './views/ExerciseLibraryView.tsx';
import { VitalsTrackerView } from './views/VitalsTrackerView.tsx';
import { SystemStatusView } from './views/SystemStatusView.tsx';
import { ProductRoadmapView } from './views/ProductRoadmapView.tsx';
import { UniversalSubpageView } from './views/UniversalSubpageView.tsx';
import { INITIAL_PATIENT, INITIAL_AUDIT_LOGS } from './data/mockData.ts';
import { AuditLogItem, PatientData } from './types/index.ts';

export default function App() {
  const [viewMode, setViewMode] = useState<'app' | 'landing'>('app');
  const [currentRoute, setCurrentRoute] = useState<string>('home-dashboard');
  const [isSidebarOpenMobile, setIsSidebarOpenMobile] = useState<boolean>(false);
  const [patient, setPatient] = useState<PatientData>(INITIAL_PATIENT);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(INITIAL_AUDIT_LOGS);
  const [selectedVertebra, setSelectedVertebra] = useState<string>('L4');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Check URL parameters for initial view or route
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const routeParam = params.get('route');
    const viewParam = params.get('view');
    if (viewParam === 'landing') {
      setViewMode('landing');
    }
    if (routeParam) {
      setCurrentRoute(routeParam);
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleUpdatePatient = (updated: Partial<PatientData>) => {
    setPatient(prev => ({ ...prev, ...updated }));
    showToast('Patient record updated');
  };

  const handleAddAuditLog = (event: string, user: string, reason: string) => {
    const newLog: AuditLogItem = {
      id: `log-${Date.now()}`,
      time: new Date().toLocaleString('en-US', { timeZoneName: 'short' }),
      event,
      user,
      reason
    };
    setAuditLogs(prev => [newLog, ...prev]);
    showToast(`Audit Log Recorded: ${event}`);
  };

  const handleNavigate = (route: string) => {
    setCurrentRoute(route);
    if (viewMode === 'landing') {
      setViewMode('app');
    }
    const mainContent = document.getElementById('mainPageContent');
    if (mainContent) {
      mainContent.scrollTop = 0;
    }
  };

  const handlePrintCard = () => {
    window.print();
  };

  const renderActiveRoute = () => {
    switch (currentRoute) {
      case 'home-dashboard':
        return (
          <HomeDashboard
            patient={patient}
            onNavigate={handleNavigate}
            onPrintCard={handlePrintCard}
          />
        );
      case 'patient-profile':
        return (
          <PatientProfileView
            patient={patient}
            onUpdatePatient={handleUpdatePatient}
            onPrintCard={handlePrintCard}
            onNavigate={handleNavigate}
          />
        );
      case 'complete-medical-history':
        return (
          <MedicalHistoryView
            patient={patient}
            onNavigate={handleNavigate}
          />
        );
      case 'prescriptions-records':
      case 'current-medications':
        return (
          <PrescriptionsView
            patient={patient}
            onAddAuditLog={handleAddAuditLog}
          />
        );
      case 'lab-reports':
        return (
          <LabReportsView
            patient={patient}
          />
        );
      case 'mri-ct-viewer':
        return (
          <MriCtViewerView
            patient={patient}
          />
        );
      case 'vitals-height-weight':
      case 'bp-glucose':
      case 'heart-rate-spo2':
        return (
          <VitalsTrackerView
            patient={patient}
          />
        );
      case 'appointments-history':
        return (
          <AppointmentsView
            patient={patient}
            onAddAuditLog={handleAddAuditLog}
            onNavigate={handleNavigate}
          />
        );
      case 'doctors-directory':
        return (
          <DirectoryView
            type="doctors"
            onNavigate={handleNavigate}
          />
        );
      case 'physio-directory':
        return (
          <DirectoryView
            type="physios"
            onNavigate={handleNavigate}
          />
        );
      case 'hospitals-directory':
        return (
          <DirectoryView
            type="hospitals"
            onNavigate={handleNavigate}
          />
        );
      case 'laboratories-directory':
        return (
          <DirectoryView
            type="labs"
            onNavigate={handleNavigate}
          />
        );
      case 'pharmacy-info':
        return (
          <DirectoryView
            type="pharmacies"
            onNavigate={handleNavigate}
          />
        );
      case 'emergency-sos':
        return (
          <EmergencySosView
            patient={patient}
            onNavigate={handleNavigate}
            onAddAuditLog={handleAddAuditLog}
            onPrintCard={handlePrintCard}
          />
        );
      case 'emergency-file':
        return (
          <EmergencyFileView
            patient={patient}
            onPrintCard={handlePrintCard}
          />
        );
      case 'emergency-audit':
        return (
          <EmergencyAuditView
            auditLogs={auditLogs}
            onAddAuditLog={handleAddAuditLog}
          />
        );
      case 'xray-imaging':
        return (
          <SpinalImagingView
            selectedVertebra={selectedVertebra}
            onSelectVertebra={setSelectedVertebra}
            onNavigate={handleNavigate}
          />
        );
      case 'physio-dashboard':
        return (
          <PhysioDashboardView
            onNavigate={handleNavigate}
          />
        );
      case 'exercise-library':
        return (
          <ExerciseLibraryView
            onNavigate={handleNavigate}
          />
        );
      case 'ai-assistant':
        return (
          <AiAssistantView
            onNavigate={handleNavigate}
          />
        );
      case 'multilingual-urdu':
        return (
          <UrduHubView
            onNavigate={handleNavigate}
          />
        );
      case 'system-status':
        return (
          <SystemStatusView />
        );
      case 'product-roadmap':
        return (
          <ProductRoadmapView />
        );
      case 'sdg-impact':
      case 'sdg-reports':
        return (
          <SdgImpactView />
        );
      default:
        return (
          <UniversalSubpageView
            routeId={currentRoute}
            patient={patient}
            onNavigate={handleNavigate}
            onAddAuditLog={handleAddAuditLog}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 antialiased flex flex-col">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-2xl text-xs flex items-center space-x-2 border border-slate-700 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-teal-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Public Portal View */}
      {viewMode === 'landing' ? (
        <LandingPage
          onLaunchPlatform={(initialRoute) => {
            if (initialRoute) setCurrentRoute(initialRoute);
            setViewMode('app');
          }}
        />
      ) : (
        /* 2. Platform OS View */
        <div id="appView" className="flex h-screen overflow-hidden">
          {/* Main Sidebar */}
          <Sidebar
            currentRoute={currentRoute}
            onNavigate={handleNavigate}
            isOpenMobile={isSidebarOpenMobile}
            onCloseMobile={() => setIsSidebarOpenMobile(false)}
            patient={patient}
          />

          {/* Main View Container */}
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            {/* Top Navigation Bar */}
            <Header
              currentRoute={currentRoute}
              onNavigate={handleNavigate}
              onToggleSidebar={() => setIsSidebarOpenMobile(prev => !prev)}
              onToggleViewMode={() => setViewMode(prev => (prev === 'app' ? 'landing' : 'app'))}
            />

            {/* Scrollable Main Page Body */}
            <main
              id="mainPageContent"
              className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-50"
            >
              {renderActiveRoute()}
            </main>
          </div>
        </div>
      )}

      {/* 3. Dedicated Printable Emergency Card (Visible only in print media) */}
      <PrintableEmergencyCard patient={patient} />
    </div>
  );
}
